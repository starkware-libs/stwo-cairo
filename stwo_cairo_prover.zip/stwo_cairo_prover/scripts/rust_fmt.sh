#!/bin/bash

cargo fmt --all -- "$@"
