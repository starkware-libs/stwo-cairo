use cairo_air::range_checks_air::{
    RangeChecksClaim, RangeChecksInteractionClaim, RangeChecksInteractionElements,
};
use stwo::prover::backend::simd::SimdBackend;

use crate::witness::components::{
    range_check_11, range_check_12, range_check_18, range_check_18_b, range_check_19,
    range_check_19_b, range_check_19_c, range_check_19_d, range_check_19_e, range_check_19_f,
    range_check_19_g, range_check_19_h, range_check_2, range_check_3_3_3_3_3, range_check_3_6_6_3,
    range_check_4_3, range_check_4_4, range_check_4_4_4_4, range_check_5_4, range_check_6,
    range_check_7_2_5, range_check_8, range_check_9_9, range_check_9_9_b, range_check_9_9_c,
    range_check_9_9_d, range_check_9_9_e, range_check_9_9_f, range_check_9_9_g, range_check_9_9_h,
};
use crate::witness::utils::TreeBuilder;

pub struct RangeChecksClaimGenerator {
    pub rc_2_trace_generator: range_check_2::ClaimGenerator,
    pub rc_6_trace_generator: range_check_6::ClaimGenerator,
    pub rc_8_trace_generator: range_check_8::ClaimGenerator,
    pub rc_11_trace_generator: range_check_11::ClaimGenerator,
    pub rc_12_trace_generator: range_check_12::ClaimGenerator,
    pub rc_18_trace_generator: range_check_18::ClaimGenerator,
    pub rc_18_b_trace_generator: range_check_18_b::ClaimGenerator,
    pub rc_19_trace_generator: range_check_19::ClaimGenerator,
    pub rc_19_b_trace_generator: range_check_19_b::ClaimGenerator,
    pub rc_19_c_trace_generator: range_check_19_c::ClaimGenerator,
    pub rc_19_d_trace_generator: range_check_19_d::ClaimGenerator,
    pub rc_19_e_trace_generator: range_check_19_e::ClaimGenerator,
    pub rc_19_f_trace_generator: range_check_19_f::ClaimGenerator,
    pub rc_19_g_trace_generator: range_check_19_g::ClaimGenerator,
    pub rc_19_h_trace_generator: range_check_19_h::ClaimGenerator,
    pub rc_4_3_trace_generator: range_check_4_3::ClaimGenerator,
    pub rc_4_4_trace_generator: range_check_4_4::ClaimGenerator,
    pub rc_5_4_trace_generator: range_check_5_4::ClaimGenerator,
    pub rc_9_9_trace_generator: range_check_9_9::ClaimGenerator,
    pub rc_9_9_b_trace_generator: range_check_9_9_b::ClaimGenerator,
    pub rc_9_9_c_trace_generator: range_check_9_9_c::ClaimGenerator,
    pub rc_9_9_d_trace_generator: range_check_9_9_d::ClaimGenerator,
    pub rc_9_9_e_trace_generator: range_check_9_9_e::ClaimGenerator,
    pub rc_9_9_f_trace_generator: range_check_9_9_f::ClaimGenerator,
    pub rc_9_9_g_trace_generator: range_check_9_9_g::ClaimGenerator,
    pub rc_9_9_h_trace_generator: range_check_9_9_h::ClaimGenerator,
    pub rc_7_2_5_trace_generator: range_check_7_2_5::ClaimGenerator,
    pub rc_3_6_6_3_trace_generator: range_check_3_6_6_3::ClaimGenerator,
    pub rc_4_4_4_4_trace_generator: range_check_4_4_4_4::ClaimGenerator,
    pub rc_3_3_3_3_3_trace_generator: range_check_3_3_3_3_3::ClaimGenerator,
}
impl Default for RangeChecksClaimGenerator {
    fn default() -> Self {
        Self::new()
    }
}

impl RangeChecksClaimGenerator {
    pub fn new() -> Self {
        Self {
            rc_2_trace_generator: range_check_2::ClaimGenerator::new(),
            rc_6_trace_generator: range_check_6::ClaimGenerator::new(),
            rc_8_trace_generator: range_check_8::ClaimGenerator::new(),
            rc_11_trace_generator: range_check_11::ClaimGenerator::new(),
            rc_12_trace_generator: range_check_12::ClaimGenerator::new(),
            rc_18_trace_generator: range_check_18::ClaimGenerator::new(),
            rc_18_b_trace_generator: range_check_18_b::ClaimGenerator::new(),
            rc_19_trace_generator: range_check_19::ClaimGenerator::new(),
            rc_19_b_trace_generator: range_check_19_b::ClaimGenerator::new(),
            rc_19_c_trace_generator: range_check_19_c::ClaimGenerator::new(),
            rc_19_d_trace_generator: range_check_19_d::ClaimGenerator::new(),
            rc_19_e_trace_generator: range_check_19_e::ClaimGenerator::new(),
            rc_19_f_trace_generator: range_check_19_f::ClaimGenerator::new(),
            rc_19_g_trace_generator: range_check_19_g::ClaimGenerator::new(),
            rc_19_h_trace_generator: range_check_19_h::ClaimGenerator::new(),
            rc_4_3_trace_generator: range_check_4_3::ClaimGenerator::new(),
            rc_4_4_trace_generator: range_check_4_4::ClaimGenerator::new(),
            rc_5_4_trace_generator: range_check_5_4::ClaimGenerator::new(),
            rc_9_9_trace_generator: range_check_9_9::ClaimGenerator::new(),
            rc_9_9_b_trace_generator: range_check_9_9_b::ClaimGenerator::new(),
            rc_9_9_c_trace_generator: range_check_9_9_c::ClaimGenerator::new(),
            rc_9_9_d_trace_generator: range_check_9_9_d::ClaimGenerator::new(),
            rc_9_9_e_trace_generator: range_check_9_9_e::ClaimGenerator::new(),
            rc_9_9_f_trace_generator: range_check_9_9_f::ClaimGenerator::new(),
            rc_9_9_g_trace_generator: range_check_9_9_g::ClaimGenerator::new(),
            rc_9_9_h_trace_generator: range_check_9_9_h::ClaimGenerator::new(),
            rc_7_2_5_trace_generator: range_check_7_2_5::ClaimGenerator::new(),
            rc_3_6_6_3_trace_generator: range_check_3_6_6_3::ClaimGenerator::new(),
            rc_4_4_4_4_trace_generator: range_check_4_4_4_4::ClaimGenerator::new(),
            rc_3_3_3_3_3_trace_generator: range_check_3_3_3_3_3::ClaimGenerator::new(),
        }
    }
    pub fn write_trace(
        self,
        tree_builder: &mut impl TreeBuilder<SimdBackend>,
    ) -> (RangeChecksClaim, RangeChecksInteractionClaimGenerator) {
        let (rc_2_claim, rc_2_interaction_gen) =
            self.rc_2_trace_generator.write_trace(tree_builder);
        let (rc_6_claim, rc_6_interaction_gen) =
            self.rc_6_trace_generator.write_trace(tree_builder);
        let (rc_8_claim, rc_8_interaction_gen) =
            self.rc_8_trace_generator.write_trace(tree_builder);
        let (rc_11_claim, rc_11_interaction_gen) =
            self.rc_11_trace_generator.write_trace(tree_builder);
        let (rc_12_claim, rc_12_interaction_gen) =
            self.rc_12_trace_generator.write_trace(tree_builder);
        let (rc_18_claim, rc_18_interaction_gen) =
            self.rc_18_trace_generator.write_trace(tree_builder);
        let (rc_18_b_claim, rc_18_b_interaction_gen) =
            self.rc_18_b_trace_generator.write_trace(tree_builder);
        let (rc_19_claim, rc_19_interaction_gen) =
            self.rc_19_trace_generator.write_trace(tree_builder);
        let (rc_19_b_claim, rc_19_b_interaction_gen) =
            self.rc_19_b_trace_generator.write_trace(tree_builder);
        let (rc_19_c_claim, rc_19_c_interaction_gen) =
            self.rc_19_c_trace_generator.write_trace(tree_builder);
        let (rc_19_d_claim, rc_19_d_interaction_gen) =
            self.rc_19_d_trace_generator.write_trace(tree_builder);
        let (rc_19_e_claim, rc_19_e_interaction_gen) =
            self.rc_19_e_trace_generator.write_trace(tree_builder);
        let (rc_19_f_claim, rc_19_f_interaction_gen) =
            self.rc_19_f_trace_generator.write_trace(tree_builder);
        let (rc_19_g_claim, rc_19_g_interaction_gen) =
            self.rc_19_g_trace_generator.write_trace(tree_builder);
        let (rc_19_h_claim, rc_19_h_interaction_gen) =
            self.rc_19_h_trace_generator.write_trace(tree_builder);
        let (rc_4_3_claim, rc_4_3_interaction_gen) =
            self.rc_4_3_trace_generator.write_trace(tree_builder);
        let (rc_4_4_claim, rc_4_4_interaction_gen) =
            self.rc_4_4_trace_generator.write_trace(tree_builder);
        let (rc_5_4_claim, rc_5_4_interaction_gen) =
            self.rc_5_4_trace_generator.write_trace(tree_builder);
        let (rc_9_9_claim, rc_9_9_interaction_gen) =
            self.rc_9_9_trace_generator.write_trace(tree_builder);
        let (rc_9_9_b_claim, rc_9_9_b_interaction_gen) =
            self.rc_9_9_b_trace_generator.write_trace(tree_builder);
        let (rc_9_9_c_claim, rc_9_9_c_interaction_gen) =
            self.rc_9_9_c_trace_generator.write_trace(tree_builder);
        let (rc_9_9_d_claim, rc_9_9_d_interaction_gen) =
            self.rc_9_9_d_trace_generator.write_trace(tree_builder);
        let (rc_9_9_e_claim, rc_9_9_e_interaction_gen) =
            self.rc_9_9_e_trace_generator.write_trace(tree_builder);
        let (rc_9_9_f_claim, rc_9_9_f_interaction_gen) =
            self.rc_9_9_f_trace_generator.write_trace(tree_builder);
        let (rc_9_9_g_claim, rc_9_9_g_interaction_gen) =
            self.rc_9_9_g_trace_generator.write_trace(tree_builder);
        let (rc_9_9_h_claim, rc_9_9_h_interaction_gen) =
            self.rc_9_9_h_trace_generator.write_trace(tree_builder);
        let (rc_7_2_5_claim, rc_7_2_5_interaction_gen) =
            self.rc_7_2_5_trace_generator.write_trace(tree_builder);
        let (rc_3_6_6_3_claim, rc_3_6_6_3_interaction_gen) =
            self.rc_3_6_6_3_trace_generator.write_trace(tree_builder);
        let (rc_4_4_4_4_claim, rc_4_4_4_4_interaction_gen) =
            self.rc_4_4_4_4_trace_generator.write_trace(tree_builder);
        let (rc_3_3_3_3_3_claim, rc_3_3_3_3_3_interaction_gen) =
            self.rc_3_3_3_3_3_trace_generator.write_trace(tree_builder);
        (
            RangeChecksClaim {
                rc_2: rc_2_claim,
                rc_6: rc_6_claim,
                rc_8: rc_8_claim,
                rc_11: rc_11_claim,
                rc_12: rc_12_claim,
                rc_18: rc_18_claim,
                rc_18_b: rc_18_b_claim,
                rc_19: rc_19_claim,
                rc_19_b: rc_19_b_claim,
                rc_19_c: rc_19_c_claim,
                rc_19_d: rc_19_d_claim,
                rc_19_e: rc_19_e_claim,
                rc_19_f: rc_19_f_claim,
                rc_19_g: rc_19_g_claim,
                rc_19_h: rc_19_h_claim,
                rc_4_3: rc_4_3_claim,
                rc_4_4: rc_4_4_claim,
                rc_5_4: rc_5_4_claim,
                rc_9_9: rc_9_9_claim,
                rc_9_9_b: rc_9_9_b_claim,
                rc_9_9_c: rc_9_9_c_claim,
                rc_9_9_d: rc_9_9_d_claim,
                rc_9_9_e: rc_9_9_e_claim,
                rc_9_9_f: rc_9_9_f_claim,
                rc_9_9_g: rc_9_9_g_claim,
                rc_9_9_h: rc_9_9_h_claim,
                rc_7_2_5: rc_7_2_5_claim,
                rc_3_6_6_3: rc_3_6_6_3_claim,
                rc_4_4_4_4: rc_4_4_4_4_claim,
                rc_3_3_3_3_3: rc_3_3_3_3_3_claim,
            },
            RangeChecksInteractionClaimGenerator {
                rc_2_interaction_gen,
                rc_6_interaction_gen,
                rc_8_interaction_gen,
                rc_11_interaction_gen,
                rc_12_interaction_gen,
                rc_18_interaction_gen,
                rc_18_b_interaction_gen,
                rc_19_interaction_gen,
                rc_19_b_interaction_gen,
                rc_19_c_interaction_gen,
                rc_19_d_interaction_gen,
                rc_19_e_interaction_gen,
                rc_19_f_interaction_gen,
                rc_19_g_interaction_gen,
                rc_19_h_interaction_gen,
                rc_4_3_interaction_gen,
                rc_4_4_interaction_gen,
                rc_5_4_interaction_gen,
                rc_9_9_interaction_gen,
                rc_9_9_b_interaction_gen,
                rc_9_9_c_interaction_gen,
                rc_9_9_d_interaction_gen,
                rc_9_9_e_interaction_gen,
                rc_9_9_f_interaction_gen,
                rc_9_9_g_interaction_gen,
                rc_9_9_h_interaction_gen,
                rc_7_2_5_interaction_gen,
                rc_3_6_6_3_interaction_gen,
                rc_4_4_4_4_interaction_gen,
                rc_3_3_3_3_3_interaction_gen,
            },
        )
    }
}

pub struct RangeChecksInteractionClaimGenerator {
    rc_2_interaction_gen: range_check_2::InteractionClaimGenerator,
    rc_6_interaction_gen: range_check_6::InteractionClaimGenerator,
    rc_8_interaction_gen: range_check_8::InteractionClaimGenerator,
    rc_11_interaction_gen: range_check_11::InteractionClaimGenerator,
    rc_12_interaction_gen: range_check_12::InteractionClaimGenerator,
    rc_18_interaction_gen: range_check_18::InteractionClaimGenerator,
    rc_18_b_interaction_gen: range_check_18_b::InteractionClaimGenerator,
    rc_19_interaction_gen: range_check_19::InteractionClaimGenerator,
    rc_19_b_interaction_gen: range_check_19_b::InteractionClaimGenerator,
    rc_19_c_interaction_gen: range_check_19_c::InteractionClaimGenerator,
    rc_19_d_interaction_gen: range_check_19_d::InteractionClaimGenerator,
    rc_19_e_interaction_gen: range_check_19_e::InteractionClaimGenerator,
    rc_19_f_interaction_gen: range_check_19_f::InteractionClaimGenerator,
    rc_19_g_interaction_gen: range_check_19_g::InteractionClaimGenerator,
    rc_19_h_interaction_gen: range_check_19_h::InteractionClaimGenerator,
    rc_4_3_interaction_gen: range_check_4_3::InteractionClaimGenerator,
    rc_4_4_interaction_gen: range_check_4_4::InteractionClaimGenerator,
    rc_5_4_interaction_gen: range_check_5_4::InteractionClaimGenerator,
    rc_9_9_interaction_gen: range_check_9_9::InteractionClaimGenerator,
    rc_9_9_b_interaction_gen: range_check_9_9_b::InteractionClaimGenerator,
    rc_9_9_c_interaction_gen: range_check_9_9_c::InteractionClaimGenerator,
    rc_9_9_d_interaction_gen: range_check_9_9_d::InteractionClaimGenerator,
    rc_9_9_e_interaction_gen: range_check_9_9_e::InteractionClaimGenerator,
    rc_9_9_f_interaction_gen: range_check_9_9_f::InteractionClaimGenerator,
    rc_9_9_g_interaction_gen: range_check_9_9_g::InteractionClaimGenerator,
    rc_9_9_h_interaction_gen: range_check_9_9_h::InteractionClaimGenerator,
    rc_7_2_5_interaction_gen: range_check_7_2_5::InteractionClaimGenerator,
    rc_3_6_6_3_interaction_gen: range_check_3_6_6_3::InteractionClaimGenerator,
    rc_4_4_4_4_interaction_gen: range_check_4_4_4_4::InteractionClaimGenerator,
    rc_3_3_3_3_3_interaction_gen: range_check_3_3_3_3_3::InteractionClaimGenerator,
}
impl RangeChecksInteractionClaimGenerator {
    pub fn write_interaction_trace(
        self,
        tree_builder: &mut impl TreeBuilder<SimdBackend>,
        interaction_elements: &RangeChecksInteractionElements,
    ) -> RangeChecksInteractionClaim {
        let rc_2_interaction_claim = self
            .rc_2_interaction_gen
            .write_interaction_trace(tree_builder, &interaction_elements.rc_2);
        let rc_6_interaction_claim = self
            .rc_6_interaction_gen
            .write_interaction_trace(tree_builder, &interaction_elements.rc_6);
        let rc_8_interaction_claim = self
            .rc_8_interaction_gen
            .write_interaction_trace(tree_builder, &interaction_elements.rc_8);
        let rc_11_interaction_claim = self
            .rc_11_interaction_gen
            .write_interaction_trace(tree_builder, &interaction_elements.rc_11);
        let rc_12_interaction_claim = self
            .rc_12_interaction_gen
            .write_interaction_trace(tree_builder, &interaction_elements.rc_12);
        let rc_18_interaction_claim = self
            .rc_18_interaction_gen
            .write_interaction_trace(tree_builder, &interaction_elements.rc_18);
        let rc_18_b_interaction_claim = self
            .rc_18_b_interaction_gen
            .write_interaction_trace(tree_builder, &interaction_elements.rc_18_b);
        let rc_19_interaction_claim = self
            .rc_19_interaction_gen
            .write_interaction_trace(tree_builder, &interaction_elements.rc_19);
        let rc_19_b_interaction_claim = self
            .rc_19_b_interaction_gen
            .write_interaction_trace(tree_builder, &interaction_elements.rc_19_b);
        let rc_19_c_interaction_claim = self
            .rc_19_c_interaction_gen
            .write_interaction_trace(tree_builder, &interaction_elements.rc_19_c);
        let rc_19_d_interaction_claim = self
            .rc_19_d_interaction_gen
            .write_interaction_trace(tree_builder, &interaction_elements.rc_19_d);
        let rc_19_e_interaction_claim = self
            .rc_19_e_interaction_gen
            .write_interaction_trace(tree_builder, &interaction_elements.rc_19_e);
        let rc_19_f_interaction_claim = self
            .rc_19_f_interaction_gen
            .write_interaction_trace(tree_builder, &interaction_elements.rc_19_f);
        let rc_19_g_interaction_claim = self
            .rc_19_g_interaction_gen
            .write_interaction_trace(tree_builder, &interaction_elements.rc_19_g);
        let rc_19_h_interaction_claim = self
            .rc_19_h_interaction_gen
            .write_interaction_trace(tree_builder, &interaction_elements.rc_19_h);
        let rc_4_3_interaction_claim = self
            .rc_4_3_interaction_gen
            .write_interaction_trace(tree_builder, &interaction_elements.rc_4_3);
        let rc_4_4_interaction_claim = self
            .rc_4_4_interaction_gen
            .write_interaction_trace(tree_builder, &interaction_elements.rc_4_4);
        let rc_5_4_interaction_claim = self
            .rc_5_4_interaction_gen
            .write_interaction_trace(tree_builder, &interaction_elements.rc_5_4);
        let rc_9_9_interaction_claim = self
            .rc_9_9_interaction_gen
            .write_interaction_trace(tree_builder, &interaction_elements.rc_9_9);
        let rc_9_9_b_interaction_claim = self
            .rc_9_9_b_interaction_gen
            .write_interaction_trace(tree_builder, &interaction_elements.rc_9_9_b);
        let rc_9_9_c_interaction_claim = self
            .rc_9_9_c_interaction_gen
            .write_interaction_trace(tree_builder, &interaction_elements.rc_9_9_c);
        let rc_9_9_d_interaction_claim = self
            .rc_9_9_d_interaction_gen
            .write_interaction_trace(tree_builder, &interaction_elements.rc_9_9_d);
        let rc_9_9_e_interaction_claim = self
            .rc_9_9_e_interaction_gen
            .write_interaction_trace(tree_builder, &interaction_elements.rc_9_9_e);
        let rc_9_9_f_interaction_claim = self
            .rc_9_9_f_interaction_gen
            .write_interaction_trace(tree_builder, &interaction_elements.rc_9_9_f);
        let rc_9_9_g_interaction_claim = self
            .rc_9_9_g_interaction_gen
            .write_interaction_trace(tree_builder, &interaction_elements.rc_9_9_g);
        let rc_9_9_h_interaction_claim = self
            .rc_9_9_h_interaction_gen
            .write_interaction_trace(tree_builder, &interaction_elements.rc_9_9_h);
        let rc_7_2_5_interaction_claim = self
            .rc_7_2_5_interaction_gen
            .write_interaction_trace(tree_builder, &interaction_elements.rc_7_2_5);
        let rc_3_6_6_3_interaction_claim = self
            .rc_3_6_6_3_interaction_gen
            .write_interaction_trace(tree_builder, &interaction_elements.rc_3_6_6_3);
        let rc_4_4_4_4_interaction_claim = self
            .rc_4_4_4_4_interaction_gen
            .write_interaction_trace(tree_builder, &interaction_elements.rc_4_4_4_4);
        let rc_3_3_3_3_3_interaction_claim = self
            .rc_3_3_3_3_3_interaction_gen
            .write_interaction_trace(tree_builder, &interaction_elements.rc_3_3_3_3_3);
        RangeChecksInteractionClaim {
            rc_2: rc_2_interaction_claim,
            rc_6: rc_6_interaction_claim,
            rc_8: rc_8_interaction_claim,
            rc_11: rc_11_interaction_claim,
            rc_12: rc_12_interaction_claim,
            rc_18: rc_18_interaction_claim,
            rc_18_b: rc_18_b_interaction_claim,
            rc_19: rc_19_interaction_claim,
            rc_19_b: rc_19_b_interaction_claim,
            rc_19_c: rc_19_c_interaction_claim,
            rc_19_d: rc_19_d_interaction_claim,
            rc_19_e: rc_19_e_interaction_claim,
            rc_19_f: rc_19_f_interaction_claim,
            rc_19_g: rc_19_g_interaction_claim,
            rc_19_h: rc_19_h_interaction_claim,
            rc_4_3: rc_4_3_interaction_claim,
            rc_4_4: rc_4_4_interaction_claim,
            rc_5_4: rc_5_4_interaction_claim,
            rc_9_9: rc_9_9_interaction_claim,
            rc_9_9_b: rc_9_9_b_interaction_claim,
            rc_9_9_c: rc_9_9_c_interaction_claim,
            rc_9_9_d: rc_9_9_d_interaction_claim,
            rc_9_9_e: rc_9_9_e_interaction_claim,
            rc_9_9_f: rc_9_9_f_interaction_claim,
            rc_9_9_g: rc_9_9_g_interaction_claim,
            rc_9_9_h: rc_9_9_h_interaction_claim,
            rc_7_2_5: rc_7_2_5_interaction_claim,
            rc_3_6_6_3: rc_3_6_6_3_interaction_claim,
            rc_4_4_4_4: rc_4_4_4_4_interaction_claim,
            rc_3_3_3_3_3: rc_3_3_3_3_3_interaction_claim,
        }
    }
}
